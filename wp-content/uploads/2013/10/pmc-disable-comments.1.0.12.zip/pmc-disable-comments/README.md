pmc-disable-comments
====================

Extends wordpress disable comments functionality for individual post types. Selectively disable/enable comments on individual posts while having the power to choose a default settings for each post type.